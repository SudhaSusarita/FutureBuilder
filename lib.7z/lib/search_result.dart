/*
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hotelbooking/api/api.dart';
import 'package:hotelbooking/data/near_by.dart';
import 'package:hotelbooking/models/model_searchlist.dart';
import 'package:hotelbooking/screens/nearBy/filter_pg.dart';
import 'package:hotelbooking/models/model_searchResult.dart';
import 'hotel_inner_page.dart';
import 'package:hotelbooking/utils/colors.dart';
import 'package:http/http.dart' as http;
import 'package:hotelbooking/utils/dimensions.dart';
import 'package:hotelbooking/widgets/my_rating.dart';

class SearchResultScreen extends StatefulWidget {
  final String searchText;
  final String city;
  final String pgName;
  const SearchResultScreen({Key key, this.searchText,this.city, this.pgName }) : super(key: key);


  @override
  _SearchResultScreenState createState() => _SearchResultScreenState();
}

class _SearchResultScreenState extends State<SearchResultScreen> {
  String url = "65.0.145.198:4080";
  SearchResultDataModel searchedData;

  Future<SearchResultDataModel> getSearchResult() async {
    final queryParams = {"pgName": "Pa", "state": "Tamil Nadu", "city" : "Chennai"};
    final response = await http.get(
        Uri.http(url, "api/v1/searchMain", queryParams),
        headers: {HttpHeaders.contentTypeHeader: "application/json"});
    var data = response.body;
    //searchedData = searchResultDataModelFromJson(response.body);

    print("$data, Response Code: ${response.statusCode}");
    print(data);

    if (response.statusCode == 200) {
      return searchResultDataModelFromJson(response.body);
    } else {
      return null;
    }
  }

  @override
  void initState() {
    getSearchResult();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: CustomColor.primaryColor,
          title: Text(
            "Search Results",
            style: GoogleFonts.roboto(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 20.0,
            ),
          ),
          centerTitle: true,
          leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Container(
                padding: EdgeInsets.all(15.0),
                child: Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                  size: 26.0,
                ),
              )),
          actions: [
            GestureDetector(
                child: Padding(
                  padding: const EdgeInsets.all(9.0),
                  child: Image.asset(
                    "assets/filter.png",
                    width: 26.0,
                    height: 26.0,
                    color: Colors.white,
                  ),
                ),
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => FilterPG()));
                }),
            SizedBox(width: 6.0),
          ],
        ),
        body: Container(
          margin: EdgeInsets.only(top: 15.0),
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.only(left: 17.0, right: 17.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "${widget.searchText}, Tamil Nadu.",
                      style: GoogleFonts.roboto(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 18.0,
                      ),
                    ),
                    Text(
                      "24 Properties",
                      style: GoogleFonts.roboto(
                        color: Color(0xff888888).withOpacity(0.9),
                        fontSize: 13.0,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10.0),
              Expanded(
                child: Container(
                  padding: EdgeInsets.only(left: 15.0, right: 15.0),
                  width: MediaQuery.of(context).size.width,
              child: FutureBuilder<SearchResultDataModel>(future: getSearchResult(),
     builder: (BuildContext context, snapshot) {
    if (snapshot.hasData) {
      return ListView.builder(
        itemCount: snapshot.data.data.length,
        scrollDirection: Axis.vertical,
        itemBuilder: (context, index) {
          NearBy nearBy = NearByList.list()[index];
          return GestureDetector(
            child: Container(
              margin: EdgeInsets.only(bottom: 5.0),
              width: MediaQuery
                  .of(context)
                  .size
                  .width,
              height: 180.0,
              child: Stack(
                children: [
                  Container(
                    width: MediaQuery
                        .of(context)
                        .size
                        .width * 0.38,
                    child: Card(
                      shape: RoundedRectangleBorder(
                          borderRadius:
                          BorderRadius.circular(13.0)),
                      elevation: 4.0,
                      child: Stack(
                        children: [
                          ClipRRect(
                            borderRadius:
                            BorderRadius.circular(13.0),
                            child: Image.asset(
                              nearBy.image[0],
                              fit: BoxFit.cover,
                              height: 170.0,
                            ),
                          ),
                          Positioned(
                            child: InkWell(
                              onTap: () {},
                              child: Container(
                                width: 30.0,
                                height: 30.0,
                                decoration: BoxDecoration(
                                  color:
                                  Colors.black.withOpacity(0.4),
                                  borderRadius:
                                  BorderRadius.circular(15.0),
                                ),
                                child: Icon(Icons.favorite_border,
                                    size: 16.0,
                                    color: Colors.white),
                              ),
                            ),
                            top: 5.0,
                            right: 5.0,
                          ),
                          */
/*Positioned(
                                        child: InkWell(
                                          onTap: () {},
                                          child: Container(
                                            width: 30.0,
                                            height: 30.0,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(15.0),
                                            ),
                                            child: Icon(Icons.call,
                                                size: 16.0, color: Colors.grey),
                                          ),
                                        ),
                                        bottom: 5.0,
                                        right: 5.0,
                                      ),
                                      Positioned(
                                        child: InkWell(
                                          onTap: () {},
                                          child: Container(
                                            width: 30.0,
                                            height: 30.0,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(15.0),
                                            ),
                                            child: Icon(Icons.mail,
                                                size: 16.0, color: Colors.grey),
                                          ),
                                        ),
                                        bottom: 5.0,
                                        right: 5.0,
                                      ),*//*

                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    left: MediaQuery
                        .of(context)
                        .size
                        .width * 0.357,
                    top: 20.0,
                    child: Container(
                      width:
                      MediaQuery
                          .of(context)
                          .size
                          .width * 0.54,
                      height: 140.0,
                      child: Card(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                                topRight: Radius.circular(13.0),
                                bottomRight:
                                Radius.circular(13.0))),
                        elevation: 4.0,
                        child: Container(
                          padding: EdgeInsets.only(
                              left: 10.0,
                              right: 10.0,
                              top: 7.0,
                              bottom: 7.0),
                          child: Column(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceEvenly,
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              Text(
                                nearBy.name,
                                style: GoogleFonts.roboto(
                                    color: Colors.black,
                                    fontSize:
                                    Dimensions.largeTextSize,
                                    fontWeight: FontWeight.bold),
                              ),
                              */
/*Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              MyRating(
                                                rating: nearBy.rating,
                                                size: 13.0,
                                              ),
                                              SizedBox(
                                                width: Dimensions.radius,
                                              ),
                                              Text(
                                                nearBy.rating,
                                                style: GoogleFonts.roboto(
                                                  color:
                                                      CustomColor.redDarkColor,
                                                  fontSize: 12.0,
                                                ),
                                              ),
                                            ],
                                          ),
                                          Text(
                                            "Rs ${nearBy.price}",
                                            style: GoogleFonts.roboto(
                                              color: CustomColor.redDarkColor,
                                              fontSize: 13.0,
                                            ),
                                          ),*//*

                              Text(
                                "- - - - - - - - - - - - - - - - - - -",
                                style: GoogleFonts.roboto(
                                    color: Color(0xffa9a8b7),
                                    fontSize: 16.0),
                              ),
                              Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment
                                      .spaceBetween,
                                  children: [
                                    Icon(
                                      Icons.wifi,
                                      size: 14.0,
                                      color: Color(0x88777777),
                                    ),
                                    Image.asset(
                                        "assets/inner_page/tv.png",
                                        height: 16.0,
                                        width: 16.0),
                                    Image.asset(
                                        "assets/inner_page/ac.png",
                                        height: 16.0,
                                        width: 16.0),
                                    Image.asset(
                                        "assets/inner_page/power.png",
                                        height: 16.0,
                                        width: 16.0),
                                    Image.asset(
                                        "assets/inner_page/cctv.png",
                                        height: 16.0,
                                        width: 16.0),
                                    Image.asset(
                                        "assets/inner_page/car_parking.png",
                                        height: 16.0,
                                        width: 16.0),
                                  ]),
                              Row(
                                children: [
                                  Image.asset(
                                      "assets/inner_page/location.png",
                                      height: 12.0,
                                      width: 12.0),
                                  Text(" ${widget.searchText}",
                                      style: GoogleFonts.roboto(
                                          color: Color(0xff888888)
                                              .withOpacity(0.9),
                                          fontSize: 11.0)),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            onTap: () {
              */
/*Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => HotelInnerPage(pgId: snapshot.data.data[index].id)));*//*

            },
          );
        },
      );
    }

                        else
                        {
                        return Center(
                        child: Text("No data",
                        style: TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5)),
                        );
                        }
  }
  ),
                )
              ),
            ]
          ),
        ),
      ),
    );
  }
}
*/
