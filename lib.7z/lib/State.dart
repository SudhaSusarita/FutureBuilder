/*

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hotelbooking/screens/auth/otp/city_selection.dart';

import 'package:sizer/sizer.dart';

class State_Selection extends StatelessWidget {
  const State_Selection({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          body: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.all(10),
              margin: EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children:
                <Widget>[
                  Stack(
                    children: [
                      Container(
                        alignment: Alignment.topCenter,
                        margin: EdgeInsets.only(top: 3.0),
                        child: Image.asset(
                          'assets/logo/Logo.png',
                          height: 140.0,
                          width: 140.0,
                        ),
                      ),
                    ],
                  ),
                  Text('Select Your State',
                      style: TextStyle(
                        fontSize: 20,
                        color: Color(0xFF060616),
                        fontWeight: FontWeight.bold,
                      )),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    'We are present in those cities!',
                    style: TextStyle(color: Color(0xFFb6b9c5)),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: FutureBuilder<dynamic>(
                            future: getState(),
                            builder: (BuildContext context,
                                AsyncSnapshot<dynamic> snapshot) {
                              if (snapshot.hasData) {
                                return
                                  GestureDetector(
                                    child:
                                    Column(
                                      children: [
                                        Row(
                                          children: [
                                            Stack(
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                    BorderRadius.circular(30),
                                                  ),
                                                  height: 85,
                                                  child: SvgPicture.asset(
                                                      "assets/Language icon/Chennai.svg",
                                                      color: Colors.grey),
                                                ),
                                                Positioned(
                                                  child: Container(
                                                      width: 20.0,
                                                      height: 20.0,
                                                      decoration: BoxDecoration(
                                                        color: Colors.black
                                                            .withOpacity(0.4),
                                                        borderRadius:
                                                        BorderRadius.circular(18.0),
                                                      ),
                                                      child: CircleAvatar(
                                                        radius: 10,
                                                        backgroundColor: Colors.green,
                                                        child: Icon(
                                                          Icons.check,
                                                          size: 15,
                                                        ),
                                                      )),
                                                  top: 0.0,
                                                  right: 0.0,
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        Text(
                                          snapshot.data[0],
                                          style: GoogleFonts.poppins(
                                              fontSize: 15, color: Color(0xFFb6b9c5)),
                                        ),
                                      ],
                                    ),
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => City()));
                                    }),

                              }

                              else
                              {
                              return Center(
                              child: Text("No data",
                              style: TextStyle(
                              fontSize: 20.0,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5)),
                              );
                              }
                            }
                        )














                      ),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Stack(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      height: 85,
                                      child: SvgPicture.asset(
                                          "assets/Language icon/Coimbatore.svg",
                                          color: Colors.grey),
                                    ),
                                    Positioned(
                                      width: 35.0,
                                      height: 35.0,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/Language icon/new.png",
                                        ),
                                      ),
                                      top: -2.0,
                                      right: -4.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              'Chandigarh',
                              style: GoogleFonts.poppins(
                                  fontSize: 15, color: Color(0xFFb6b9c5)),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Stack(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      height: 85,
                                      child: SvgPicture.asset(
                                          "assets/Language icon/Bangalore.svg",
                                          color: Colors.grey),
                                    ),
                                    Positioned(
                                      width: 35.0,
                                      height: 35.0,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/Language icon/new.png",
                                        ),
                                      ),
                                      top: -2.0,
                                      right: -4.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              'Odisa',
                              style: GoogleFonts.poppins(
                                  fontSize: 15, color: Color(0xFFb6b9c5)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Stack(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      height: 85,
                                      child: SvgPicture.asset(
                                          "assets/Language icon/Mumbai.svg",
                                          color: Colors.grey),
                                    ),
                                    Positioned(
                                      width: 35.0,
                                      height: 35.0,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/Language icon/new.png",
                                        ),
                                      ),
                                      top: -2.0,
                                      right: -4.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              'Assam',
                              style: GoogleFonts.poppins(
                                  fontSize: 15, color: Color(0xFFb6b9c5)),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Stack(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      height: 85,
                                      child: SvgPicture.asset(
                                          "assets/Language icon/Noida.svg",
                                          color: Colors.grey),
                                    ),
                                    Positioned(
                                      width: 35.0,
                                      height: 35.0,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/Language icon/new.png",
                                        ),
                                      ),
                                      top: -2.0,
                                      right: -4.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              'Kerala',
                              style: GoogleFonts.poppins(
                                  fontSize: 15, color: Color(0xFFb6b9c5)),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Stack(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      height: 85,
                                      child: SvgPicture.asset(
                                          "assets/Language icon/Kota.svg",
                                          color: Colors.grey),
                                    ),
                                    Positioned(
                                      width: 35.0,
                                      height: 35.0,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/Language icon/new.png",
                                        ),
                                      ),
                                      top: -2.0,
                                      right: -4.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              'Delhi',
                              style: GoogleFonts.poppins(
                                  fontSize: 15, color: Color(0xFFb6b9c5)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Stack(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      height: 85,
                                      child: SvgPicture.asset(
                                          "assets/Language icon/Kota.svg",
                                          color: Colors.grey),
                                    ),
                                    Positioned(
                                      width: 35.0,
                                      height: 35.0,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/Language icon/new.png",
                                        ),
                                      ),
                                      top: -2.0,
                                      right: -4.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              'Goa',
                              style: GoogleFonts.poppins(
                                  fontSize: 15, color: Color(0xFFb6b9c5)),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Stack(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      height: 85,
                                      child: SvgPicture.asset(
                                          "assets/Language icon/Pune.svg",
                                          color: Colors.grey),
                                    ),
                                    Positioned(
                                      width: 35.0,
                                      height: 35.0,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/Language icon/new.png",
                                        ),
                                      ),
                                      top: -2.0,
                                      right: -4.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              'Gujarat',
                              style: GoogleFonts.poppins(
                                  fontSize: 15, color: Color(0xFFb6b9c5)),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Stack(
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      height: 85,
                                      child: SvgPicture.asset(
                                          "assets/Language icon/Gurugram.svg",
                                          color: Colors.grey),
                                    ),
                                    Positioned(
                                      width: 35.0,
                                      height: 35.0,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/Language icon/new.png",
                                        ),
                                      ),
                                      top: -2.0,
                                      right: -4.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              'Bihar',
                              style: GoogleFonts.poppins(
                                  fontSize: 15, color: Color(0xFFb6b9c5)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(11),
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey,
                                blurRadius: 3.0,
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                      height: 85,
                                      child: SvgPicture.asset(
                                          "assets/Language icon/Hyderabad.svg",
                                          color: Colors.grey),
                                    ),
                                    Positioned(
                                      width: 35.0,
                                      height: 35.0,
                                      child: Container(
                                        child: Image.asset(
                                          "assets/Language icon/new.png",
                                        ),
                                      ),
                                      top: -2.0,
                                      right: -4.0,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              'AndraPradesh',
                              style: GoogleFonts.poppins(
                                  fontSize: 15, color: Color(0xFFb6b9c5)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 30,
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }

  Future<dynamic> getDetails() async{
    final response = await http.get("http://192.168.1.21:8080/displayList");
    return json.decode(response.body);
  }
}
*/
